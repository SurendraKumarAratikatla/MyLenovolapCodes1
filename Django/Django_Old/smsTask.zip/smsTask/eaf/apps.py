from django.apps import AppConfig


class EafConfig(AppConfig):
    name = 'eaf'
